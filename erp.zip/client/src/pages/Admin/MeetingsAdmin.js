import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

import { 
  Video, 
  Plus, 
  Calendar, 
  Clock, 
  User, 
  ExternalLink, 
  Search,
  MoreVertical,
  ChevronRight
} from 'lucide-react';
import { getAllMeetings } from '../../services/meetingService';
import './MeetingsAdmin.css'; // ADD THIS IMPORT

const MeetingsAdmin = () => {
  const [meetings, setMeetings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    (async () => {
      try {
        setLoading(true);
        const data = await getAllMeetings();
        setMeetings(data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const filteredMeetings = meetings.filter(m => 
    m.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Helper to determine meeting status for styling
  const getMeetingStatus = (dateString) => {
    const scheduled = new Date(dateString);
    const now = new Date();
    const diff = scheduled.getTime() - now.getTime();
    
    if (Math.abs(diff) < 3600000 && diff < 0) return 'live'; // Within last hour
    if (diff < 0) return 'past';
    return 'upcoming';
  };

  return (
    <div className="min-h-screen">
      <div className="max-w-6xl">
        {/* Header Section */}
        <div className="header-section">
          <div>
            <h1 className="text-3xl">Meetings</h1>
            <p className="header-subtitle">Manage corporate syncs and virtual huddles.</p>
          </div>
          
          <button 
            onClick={() => navigate('/admin/meetings/create')}
            className="new-meeting-btn"
          >
            <Plus size={20} />
            Schedule New Meeting
          </button>
        </div>

        {/* Stats & Filter Bar */}
        <div className="stats-filter">
          <div className="search-container">
            <Search className="search-icon" size={20} />
            <input 
              type="text"
              placeholder="Search by meeting title..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="search-input"
            />
          </div>
          <div className="stats-card">
            <span className="stats-label">Total:</span>
            <span className="stats-number">{meetings.length}</span>
          </div>
        </div>

        {/* Meetings Grid/List */}
        {loading ? (
          <div className="meetings-grid">
            {[1, 2, 3, 4].map(i => (
              <div key={i} className="skeleton" />
            ))}
          </div>
        ) : filteredMeetings.length > 0 ? (
          <div className="meetings-grid">
            {filteredMeetings.map((m) => {
              const status = getMeetingStatus(m.scheduledAt);
              return (
                <div key={m._id} className="meeting-card group">
                  <div className="card-content">
                    <div className="card-header">
                      <div className={`status-badge ${status === 'live' ? 'status-live' : 'status-upcoming'}`}>
                        <Video size={24} />
                      </div>
                      <div className="card-actions">
                        {status === 'live' && (
                          <span className="live-badge">
                            <span className="live-dot" />
                            Live Now
                          </span>
                        )}
                        <button className="more-btn">
                          <MoreVertical size={20} />
                        </button>
                      </div>
                    </div>

                    <h3 className="meeting-title">{m.title}</h3>
                    <p className="meeting-description">
                      {m.description || "No description provided for this session."}
                    </p>

                    <div className="meeting-details">
                      <div className="detail-item">
                        <Calendar size={16} className="detail-icon" />
                        <span className="detail-text">{new Date(m.scheduledAt).toLocaleDateString(undefined, { dateStyle: 'long' })}</span>
                      </div>
                      <div className="detail-item">
                        <Clock size={16} className="detail-icon" />
                        <span className="detail-text">{new Date(m.scheduledAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                      </div>
                      <div className="detail-item">
                        <User size={14} className="detail-icon" />
                        <span className="detail-text">Organized by <span className="organizer-name">{m.createdBy?.name || 'Admin'}</span></span>
                      </div>
                    </div>
                  </div>

                  {/* Footer Action */}
                  <div className="card-footer">
                    {m.url ? (
                      <a 
                        href={m.url} 
                        target="_blank" 
                        rel="noreferrer"
                        className="join-link"
                      >
                        Join Discussion <ExternalLink size={16} />
                      </a>
                    ) : (
                      <span className="no-link">No link provided</span>
                    )}
                    
                    <button className="chevron-btn">
                      <ChevronRight size={20} />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="empty-state">
            <div className="empty-icon">
              <Calendar className="empty-icon-svg" size={40} />
            </div>
            <h3 className="empty-title">No meetings found</h3>
            <p className="empty-subtitle">Try a different search or create a new session.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default MeetingsAdmin;
